echo '[!!] installing...'
pip3 install requests
echo 'Done Installing'
echo 'Running it now '
python3 yomama.py -t manual
